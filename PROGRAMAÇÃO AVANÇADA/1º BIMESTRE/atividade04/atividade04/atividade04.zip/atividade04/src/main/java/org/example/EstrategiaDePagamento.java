package org.example;

public interface EstrategiaDePagamento {
    void processarPagamento(double valor); // Metodo para processar o pagamento
}
