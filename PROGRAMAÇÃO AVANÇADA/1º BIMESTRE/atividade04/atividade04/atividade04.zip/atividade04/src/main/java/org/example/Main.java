package org.example;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Exibe o menu de opções
        System.out.println("Escolha o metodo de pagamento:");
        System.out.println("1: Pix");
        System.out.println("2: Cartao de Credito");
        System.out.println("3: Boleto");

        // Lê a escolha do usuário
        int escolha = scanner.nextInt();

        // Solicita o valor da transação
        System.out.println("Digite o valor da transacao:");
        double valor = scanner.nextDouble();

        // Variável para armazenar a estratégia de pagamento
        EstrategiaDePagamento estrategia = null;

        // Define a estratégia de pagamento com base na escolha do usuário
        switch (escolha) {
            case 1:
                estrategia = new PagamentoPix();
                break;
            case 2:
                estrategia = new PagamentoCartaoCredito();
                break;
            case 3:
                estrategia = new PagamentoBoleto();
                break;
            default:
                System.out.println("Opcao invalida.");
                break;
        }

        // Se uma estratégia foi selecionada, cria o processador e processa o pagamento
        if (estrategia != null) {
            ProcessadorDePagamento processador = new ProcessadorDePagamento(estrategia);
            processador.processar(valor); // Processa o pagamento
        }

        scanner.close();
    }
}
